function [A, objective_value] = bs_func_avRDP(W, I, para)

objective_value = 0;
A = bs_mean_cell(W);
