function [A, objective_value] = bs_func_cvRDP(W, I, para)

alpha = 1/(1+para.mu);
% D = 1./sqrt(sum(W, 2));
% D = D*D';
% [X, Y, V] = find(W);
% if para.is_sparse
%     W = sparse( double(W) );
%     S = W.*double(D);
%     A = double( I );
%     I = double( I );
% else
%     S = W.*D;
%     A = I;
% end
for vI = 1:length(W)
    RowSum = sum(W{vI},2);
    RowSumRemap = repmat(RowSum,[1,size(W{vI},1)]);
    W{vI} = 0.5*W{vI}./RowSumRemap;
    W{vI}=W{vI}-diag(diag(W{vI})-diag(0.5));
end
objective_value = zeros(para.max_iter_diffusion, 1, 'single');

for iter = 1:para.max_iter_diffusion
    %     tic;
    for vI = 1:length(W)        
        D{vI} = 1./sqrt(sum(W{vI}, 2));
        D{vI} = D{vI}*D{vI}';
        S{vI} = W{vI}.*D{vI};       
        tempWcell = W;
        tempWcell{vI} = zeros(size(W{1}), 'like', W{1});
        sumW = zeros(size(W{1}), 'like', W{1});
        for ii = 1:length(tempWcell)
            sumW = sumW + tempWcell{ii};
        end
        sumW = sumW/(length(tempWcell)-1);
        W{vI} = alpha*(S{vI}*sumW*S{vI}') + (1-alpha)*I;
        % A = alpha*(S*A*S') + (1-alpha)*I;
        
        % Normalize W
        RowSum = sum(W{vI},2);
        RowSumRemap = repmat(RowSum,[1,size(W{vI},1)]);
        W{vI} = 0.5*W{vI}./RowSumRemap;
        W{vI}=W{vI}-diag(diag(W{vI})-diag(0.5));
    end
    %     toc;
    if para.if_debug
        objective_value(iter) = bs_compute_objective(A, D, X, Y, V, I, para);
        fprintf('After %d iteration, obj is %5.4f\n', iter, objective_value(iter) );
        if iter > 1
            if objective_value(iter-1)-objective_value(iter) < para.thres
                break;
            end
        end
    end
end
A = zeros(size(W{1}), 'like', W{1});
for ii = 1:length(W)
    A = A + W{ii};
end
A = A/length(W);
% A = single(A);
% objective_value = objective_value(1:iter);