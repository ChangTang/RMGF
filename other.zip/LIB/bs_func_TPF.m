function [A, objective_value] = bs_func_TPF(W, I, para)

alpha = 1/(1+para.mu);
D = cellfun(@(x)( 1./sqrt(sum(x, 2)) ), W, 'UniformOutput', false);
[X, Y, V] = cellfun(@(x)(find(x)), W, 'UniformOutput', false);

if para.is_sparse
    S = cellfun(@(x,y)(sparse(double(x)).*double(y*y')), W, D, 'UniformOutput', false);
    I = double( I );
else
    S = cellfun(@(x,y)(x.*(y*y')), W, D, 'UniformOutput', false);
end
A = I;
D = D{2}*D{1}';

objective_value = zeros(para.max_iter_diffusion, 1, 'single');
for iter = 1:para.max_iter_diffusion
    A = alpha*(S{2}*A*S{1}') + (1-alpha)*I;
    if para.if_debug
        objective_value(iter) = bs_compute_objective(A, D, X, Y, V, I, para);
        fprintf('After %d iteration, obj is %5.4f\n', iter, objective_value(iter) );
        if iter > 1
            if abs( objective_value(iter-1)-objective_value(iter) ) < para.thres
                break;
            end
        end
    end
end
A = single(A);
objective_value = objective_value(1:iter);