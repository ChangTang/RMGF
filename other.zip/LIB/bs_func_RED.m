function [A, out_beta, obj] = bs_func_RED(W, I, para)

alpha = para.beta/(para.mu + sum(para.beta));
D = cellfun(@(x)( 1./sqrt(sum(x, 2)) ), W, 'UniformOutput', false);
D = cellfun(@(x)( x*x' ), D, 'UniformOutput', false);
[X, Y, V] = cellfun(@(x)(find(x)), W, 'UniformOutput', false);

if para.is_sparse
    S = cellfun(@(x,y)(sparse(double(x)).*double(y)), W, D, 'UniformOutput', false);
    I = double( I );
else
    S = cellfun(@(x,y)(x.*y), W, D, 'UniformOutput', false);
end
A = I;
A_tmp = zeros([size(I), length(W)], 'like', A);
obj = zeros(para.max_iter_alternating, 1);
for ii = 1:para.max_iter_alternating
    % update A by diffusion
    tmp = zeros(para.max_iter_diffusion, 1, 'single');
    for iter = 1:para.max_iter_diffusion
%         tic;
        for v = 1:length(W)
            A_tmp(:, :, v) = alpha(v)*(S{v}*A*S{v}');
        end
%         toc;
        A_new = sum(A_tmp, 3) + (1-sum(alpha))*I;
        if para.if_debug
            tmp(iter) = bs_compute_objective(A_new, D, X, Y, V, I, para);
            fprintf('After %d iteration in diffusion, obj is %5.4f\n', iter, tmp(iter) );
            if iter > 1
                if abs( tmp(iter-1)-tmp(iter) ) < para.thres
                    break
                end
            end
        end
        A = A_new;
    end
    % update weights beta
    H = zeros(length(W), 1, 'single');
    for v = 1:length(W)
        H(v) = bs_compute_H(A, D{v}, X{v}, Y{v}, V{v}, para);
    end
    if para.fusion_type == 4
        para.beta = coordinate_descent_beta(para.beta, H, para.lambda);
    end
    alpha = para.beta/(para.mu + sum(para.beta));
    % calculate the obj
    obj(ii) = para.beta'*H + (para.mu)*sum((A(:)-I(:)).^2);
    if para.fusion_type == 4
        obj(ii) =  obj(ii) + 0.5*para.lambda*norm(para.beta);
    end
    fprintf('In the %d iteration, the obj is %.4f\n', ii, obj(ii));
    if ii > 1
        if abs( obj(ii-1)-obj(ii)) < para.thres
            break
        end
    end
end
A = single(A);
out_beta = para.beta;
end

function beta_new = coordinate_descent_beta(beta, H, lambda)
beta_new = beta;
for iter = 1:20
    for ii = 1:length(beta)
        for jj = ii+1:length(beta)
            beta_new(ii) = ( beta(ii)+beta(jj) )/2 + 0.5*( H(jj)-H(ii) )/lambda;
            beta_new(jj) = beta(ii)+beta(jj)-beta_new(ii);
            if beta_new(ii) < 0
                beta_new(ii) = 0;
                beta_new(jj) = beta(ii)+beta(jj);
            end
            if beta_new(jj) < 0
                beta_new(jj) = 0;
                beta_new(ii) = beta(ii)+beta(jj);
            end
            beta = beta_new;
        end
    end
end
end