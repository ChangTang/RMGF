function A = bs_mean_cell(B)

A = zeros(size(B{1}), 'like', B{1});
for ii = 1:length(B)
    A = A + B{ii};
end
A = A/length(B);